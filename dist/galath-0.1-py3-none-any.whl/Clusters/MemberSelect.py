class cluster:
    def __init__(self, name="cluster"):
        self._name = name

test



        ra, dec, pmra, pmdec, ra_c=0, dec_c=0, pmra_c=0, pmdec_c=0, r_radec=1, r_pm=1):
        self._ra = ra
        self._dec