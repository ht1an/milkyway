from setuptools import setup, find_packages

setup(
    name="galath",
    version=0.01,
    description=("Some frequently used functions for studying the Milky Way"),
    author='htian',
    author_email='htian_astro@163.com',
    maintainer='htian',
    maintainer_email='htian_astro@163.com',
    license='BSD License',
    packages=find_packages()
)